import { GoogleGenAI } from "@google/genai";
import { Message } from "../types";

const apiKey = process.env.API_KEY || '';
let ai: GoogleGenAI | null = null;

if (apiKey) {
  ai = new GoogleGenAI({ apiKey });
}

export const generateResponseSuggestion = async (messages: Message[], context: string): Promise<string> => {
  if (!ai) {
    // Mock response if no API key is present to ensure the UI still works for demo
    return new Promise((resolve) => {
        setTimeout(() => {
            resolve("Based on the customer's history, I recommend checking the billing cycle for invoice #INV-2024. You can offer a 10% discount code 'SORRY10' for the inconvenience.");
        }, 1500);
    });
  }

  try {
    const conversationText = messages.map(m => `${m.sender}: ${m.content}`).join('\n');
    const prompt = `
      You are a helpful customer support AI assistant for ConnectFlo.
      Context about the customer: ${context}
      
      Conversation History:
      ${conversationText}
      
      Please provide a concise, helpful, and professional suggested response for the agent to send to the customer.
      Do not include "Subject:" or other metadata, just the message body.
    `;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
    });

    return response.text || "I couldn't generate a suggestion at this time.";
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "Error generating suggestion. Please check API configuration.";
  }
};

export const analyzeSentiment = async (text: string): Promise<'POSITIVE' | 'NEUTRAL' | 'NEGATIVE'> => {
    if (!ai) return 'NEUTRAL'; // Fallback
    
    try {
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: `Analyze the sentiment of this text: "${text}". Return ONLY one word: POSITIVE, NEUTRAL, or NEGATIVE.`,
        });
        const sentiment = response.text?.trim().toUpperCase();
        if (sentiment === 'POSITIVE' || sentiment === 'NEGATIVE') return sentiment;
        return 'NEUTRAL';
    } catch (e) {
        return 'NEUTRAL';
    }
}

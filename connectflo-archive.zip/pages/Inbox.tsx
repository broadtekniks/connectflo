import React, { useState } from 'react';
import ConversationList from '../components/inbox/ConversationList';
import ChatArea from '../components/inbox/ChatArea';
import CustomerPanel from '../components/inbox/CustomerPanel';
import { MOCK_CONVERSATIONS, CURRENT_USER } from '../constants';
import { MessageSender, Message, Conversation } from '../types';

const Inbox: React.FC = () => {
  const [conversations, setConversations] = useState(MOCK_CONVERSATIONS);
  const [selectedId, setSelectedId] = useState<string>(conversations[0].id);

  const selectedConversation = conversations.find(c => c.id === selectedId) || conversations[0];

  const handleSendMessage = (text: string, isPrivate: boolean) => {
    const newMessage: Message = {
      id: `new-${Date.now()}`,
      content: text,
      sender: MessageSender.AGENT,
      timestamp: new Date().toISOString(),
      isPrivateNote: isPrivate
    };

    setConversations(prev => prev.map(c => {
      if (c.id === selectedId) {
        return {
          ...c,
          messages: [...c.messages, newMessage],
          lastActivity: new Date().toISOString()
        };
      }
      return c;
    }));
  };

  return (
    <div className="flex h-full overflow-hidden">
      <ConversationList 
        conversations={conversations} 
        selectedId={selectedId} 
        onSelect={setSelectedId} 
      />
      <ChatArea 
        conversation={selectedConversation} 
        onSendMessage={handleSendMessage}
      />
      <CustomerPanel conversation={selectedConversation} />
    </div>
  );
};

export default Inbox;
